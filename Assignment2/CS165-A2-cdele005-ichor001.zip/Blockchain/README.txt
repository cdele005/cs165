Member 1 : Clark De Leon       cdele005
Contribution: Implemented the functions in TxHandler.java
   
Member 2 : Ignacy Chorazewicz  ichor001
Contribution: Implemented the functions in Blockchain.java

